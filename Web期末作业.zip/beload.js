/**
 * 此脚本用于检测页面上的链接是否活跃，并通过颜色变化（绿色表示活跃，红色表示不活跃）来显示链接的状态。
 * 使用本地存储来保存链接的活跃状态，并在加载页面时检查此状态。
 * 如果链接的活跃状态自上次检查以来已超过7天，则会重新测试每个链接的活跃性。
 */

console.log("正在加载：链接活跃性检测" + Date())
if (localStorage.getItem("ondeload") == "true") {
    // 获取当前日期时间并格式化为特定字符串格式，用于存储
    let beloadDate = new Date()
    let beload = beloadDate.getFullYear() * 10000 + beloadDate.getMonth() * 100 + beloadDate.getDate()
    // 从本地存储获取上一次加载的时间
    let deload = localStorage.getItem("deload")
    // 创建一个对象来存储链接的活跃状态
    let list = {}
    // 从本地存储获取之前保存的链接状态，并更新到list对象中
    Object.assign(list, JSON.parse(localStorage.getItem("loaded")))

    // 遍历页面上的所有链接，并根据它们在list中的状态改变其样式
    document.querySelectorAll("a").forEach((v, k) => {
        if (list[v.href] == "true") v.style = "color: green;"
        else if (list[v.href] == "false") v.style = "color: red;"
    })

    // 检查是否需要重新测试链接的活跃性
    if (beload - Number(deload) > 7) {
        // 尝试连接服务器以进行链接活跃性测试
        fetch(`${location.href.slice(-1) == "/" ? location.href.slice(0, -1) : location.href}:93?name=connectionTest&url=${location.href}`).then((testRes) => {
            console.log("服务器已连接")
            // 遍历页面上的链接，并对每个链接进行活跃性测试
            document.querySelectorAll("a").forEach((v, k) => {
                fetch(`${location.href.slice(-1) == "/" ? location.href.slice(0, -1) : location.href}:93?name=${v.innerHTML}&url=${v.href}`).then(res => res.json()).then(data => {
                    if (data.code == "200") {
                        // 如果链接活跃，更新样式和本地存储
                        list[v.href] = "true"
                        v.style = "color: green;"
                        localStorage.setItem("loaded", JSON.stringify(list))
                    } else {
                        // 如果链接不活跃，更新样式和本地存储
                        list[v.href] = "false"
                        v.style = "color: red;"
                        localStorage.setItem("loaded", JSON.stringify(list))
                    }
                    console.log(`[server]${data.msg}`)
                }).catch(err => {
                    // 如果发生错误，尝试通过添加链接标签并监听其加载状态来检测链接
                    let p = document.createElement("link")
                    p.rel = "stylesheet"
                    p.type = "text/css"
                    p.href = v.href
                    p.onload = () => {
                        // 如果链接加载成功，更新样式和本地存储
                        list[v.href] = "true"
                        v.style = "color: green;"
                        document.querySelector("body").removeChild(p)
                        localStorage.setItem("loaded", JSON.stringify(list))
                        console.log(`链接正常：[link][200]${v.innerHTML} : ${v.href}`)
                    }
                    // 如果链接加载失败，更新样式和本地存储
                    p.onabort = () => {
                        list[v.href] = "false"
                        v.style = "color: red;"
                        document.querySelector("body").removeChild(p)
                        localStorage.setItem("loaded", JSON.stringify(list))
                        console.log(`链接失效：[link][404]${v.innerHTML} : ${v.href}`)
                    }
                    p.onerror = () => {
                        // 如果链接加载出错，更新样式和本地存储
                        list[v.href] = "false"
                        v.style = "color: red;"
                        document.querySelector("body").removeChild(p)
                        localStorage.setItem("loaded", JSON.stringify(list))
                        console.log(`链接失效：[link][404]${v.innerHTML} : ${v.href}`)
                    }
                    document.querySelector("body").appendChild(p)
                })
            })
        }).catch(testErr => {
            // 如果无法连接服务器，则只通过添加链接标签来检测链接的活跃性
            console.log("服务器未连接，本地检测")
            document.querySelectorAll("a").forEach((v, k) => {
                let p = document.createElement("link")
                p.rel = "stylesheet"
                p.type = "text/css"
                p.href = v.href
                p.onload = () => {
                    // 如果链接加载成功，更新样式和本地存储
                    list[v.href] = "true"
                    v.style = "color: green;"
                    document.querySelector("body").removeChild(p)
                    localStorage.setItem("loaded", JSON.stringify(list))
                    console.log(`链接正常：[link][200]${v.innerHTML} : ${v.href}`)
                }
                // 如果链接加载失败，更新样式和本地存储
                p.onabort = () => {
                    list[v.href] = "false"
                    v.style = "color: red;"
                    document.querySelector("body").removeChild(p)
                    localStorage.setItem("loaded", JSON.stringify(list))
                    console.log(`链接失效：[link][404]${v.innerHTML} : ${v.href}`)
                }
                p.onerror = () => {
                    // 如果链接加载出错，更新样式和本地存储
                    list[v.href] = "false"
                    v.style = "color: red;"
                    document.querySelector("body").removeChild(p)
                    localStorage.setItem("loaded", JSON.stringify(list))
                    console.log(`链接失效：[link][404]${v.innerHTML} : ${v.href}`)
                }
                document.querySelector("body").appendChild(p)
            })
        })
        // 更新本地存储中的加载时间
        localStorage.setItem("deload", beload)
    }
}
// 如果用户选择了自动加载，则启用链接活跃性检测
if (localStorage.getItem("ondeload") == 'true') document.querySelector("#box-linkavilible").checked = true
// 监听用户是否选择自动加载，并更新本地存储
document.querySelector("#box-linkavilible").onclick = (e) => {
    localStorage.setItem("ondeload", e.target.checked)
}
console.log("已加载：链接活跃性检测" + Date())