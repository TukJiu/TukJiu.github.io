/**
 * 检查当前页面URL中是否包含锚点（#），并平滑滚动到该锚点位置。
 * 该代码不接受任何参数且没有返回值。
 */
if(location.href.indexOf('#') != -1 && location.href.slice(location.href.indexOf('#')) != '#') { 
    // 如果URL中包含锚点且锚点不为空，则滚动到该锚点位置
    document.querySelector(location.href.slice(location.href.indexOf('#'))).scrollIntoView({behavior: 'smooth'});
}