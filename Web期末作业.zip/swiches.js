/**
 * 此脚本用于对页面上的 <div> 元素根据点击频率进行排序，并在页面上显示排序结果。
 * 当页面加载时，以及当用户点击特定的排序复选框时，会触发排序。
 * 用户点击 div 元素时，该元素的点击次数会增加，并根据点击次数进行重新排序。
 */

// 输出当前时间，表示脚本开始执行
console.log("正在加载：点击频率排序" + Date())

// 初始化一个空对象来存储 div 元素的点击次数
let divs = {}

// 遍历页面上所有的 div 元素，并初始化它们的点击次数为 0
document.querySelectorAll("div").forEach((v, k) => {
    divs[v.id] = 0
})

// 从本地存储中获取之前记录的 div 点击次数，并合并到当前的 divs 对象中
Object.assign(divs, JSON.parse(localStorage.getItem("divs")))

// 如果用户之前选择了排序选项，则进行排序并显示结果
if (localStorage.getItem("onsort") == 'true') {
    // 显示排序结果的区域
    document.querySelector("#shows").style = "display: block;"
    document.querySelector("#shows").innerHTML = "<p style=\"text-align: center;\">点击频次</p>"

    // 准备进行排序的 div 元素信息
    let divr = []
    let ids = 0
    for (i in divs) {
        let temps = {}
        temps.id = i
        temps.ct = divs[i]
        divr[ids] = temps
        ids++
    }

    // 过滤掉已经不存在于页面上的 div 元素
    divr = divr.filter(a => document.querySelector(`#${a.id}`) != null)

    // 根据点击次数对 div 元素进行降序排序
    ids = divr.length
    divr.sort((a, b) => {
        return b.ct - a.ct
    })

    // 更新页面以显示排序后的结果
    for (let i = 0; i < ids; i++) {
        document.querySelector("section").innerHTML += `<p id="_${divr[i].id}" onclick="document.querySelector('#${divr[i].id}').scrollIntoView({ behavior: 'smooth' })">${document.querySelector("#"+divr[i].id).querySelector("h3").innerHTML} : ${divr[i].ct}</p>`
        let p = document.createElement('div')
        p = document.querySelector(`#${divr[i].id}`)
        document.querySelector("#main").removeChild(document.querySelector(`#${divr[i].id}`))
        document.querySelector("#main").appendChild(p)
    }
}

// 设置排序复选框的初始状态
if(localStorage.getItem("onsort") == 'true') document.querySelector("#box-sortdivs").checked = true

// 监听排序复选框的点击事件，以更新本地存储的排序状态
document.querySelector("#box-sortdivs").onclick = (e)=>{
    localStorage.setItem("onsort", e.target.checked)
}

// 监听所有 div 元素的点击事件，以增加它们的点击次数并更新显示
document.querySelectorAll("a").forEach((v, k) => {
    v.onclick = (e) => {
        divs[e.target.parentNode.id] += 1
        localStorage.setItem("divs", JSON.stringify(divs))
        document.querySelector("#_"+e.target.parentNode.id).innerHTML = `${document.querySelector("#"+e.target.parentNode.id).querySelector("h3").innerHTML} : ${divs[e.target.parentNode.id]}`
    }
})

// 监听所有 h3 元素的点击事件，以平滑滚动到页面顶部
document.querySelectorAll("h3").forEach((v, k) => {
    v.onclick = (e) => {
        document.querySelector("#main").scrollIntoView({behavior: 'smooth'})
    }
})

// 输出当前时间，表示脚本执行完成
console.log("已加载：点击频率排序" + Date())