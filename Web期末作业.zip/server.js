// 导入必要的模块
const http = require('http')
const https = require('https')
const fs = require('fs')
const urls = require('url')

// 创建HTTP服务器，用于处理HTTP请求
http.createServer((req, res) => {
    // 请求日志记录
    console.log(`<网页服务> ${new Date()} [${req.socket.remoteAddress}] : starting get ${req.url}`)
    // 默认首页处理
    if (req.url === '/') req.url = '/index.html'
    // 文件读取处理
    fs.readFile(req.url.slice(1), (err, data) => {
        if (err) {
            // 404错误处理
            res.writeHead(404, { 'Content-Type': 'text/html' })
            res.end('404 Not Found')
            console.log(`<网页服务> ${new Date()} [${req.socket.remoteAddress}] : get ${req.url} 404`)
        } else {
            // 文件正常返回处理
            res.writeHead(200, { 'Content-Type': 'text/html' })
            res.end(data)
            console.log(`<网页服务> ${new Date()} [${req.socket.remoteAddress}] : get ${req.url} 200`)
        }
    })
}).listen(80)

// 创建HTTPS服务器，用于处理HTTPS请求
http.createServer((req, res) => {
    // 请求日志记录
    console.log(`<链接探测服务> ${new Date()} [${req.socket.remoteAddress}] : starting request ${req.url}`)
    // 设置跨域访问
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("charset", "utf-8")
    // 初始化响应头
    res.writeHead(200, "{'Content-Type': 'json/html'}")
    // 解析请求参数
    let schme = urls.parse(req.url, true).query
    let url = schme.url
    let name = schme.name
    // 参数完整性校验
    if (url == undefined || name == undefined) {
        // 参数不完整处理
        res.end(JSON.stringify({
            "code": "403",
            "msg": "[403]参数未完全传递",
            "name": null,
            "url": null
        }))
        console.log(`<链接探测服务> ${new Date()} [${req.socket.remoteAddress}] : request [403]参数未完全传递 ===>> ${req.url}`)
        return
    }
    // HTTP链接探测
    if (url.slice(0, 7) == "http://") {
        http.request({
            host: urls.parse(url, true).host,
            path: urls.parse(url, true).path,
            method: 'HEAD'
        }, (resr) => {
            // 链接状态处理
            if (resr.statusCode >= 200 && resr.statusCode < 400) {
                res.end(JSON.stringify({
                    "code": "200",
                    "msg": `链接正常：[200]${name} : ${url}`,
                    "name": name,
                    "url": url
                }))
                console.log(`<链接探测服务> ${new Date()} [${req.socket.remoteAddress}] : 链接正常：[200]${name} : ${url}`)
            } else {
                // 链接无效处理
                res.end(JSON.stringify({
                    "code": "404",
                    "msg": `链接无效：[404]${name} : ${url}`,
                    "name": name,
                    "url": url
                }))
                console.log(`<链接探测服务> ${new Date()} [${req.socket.remoteAddress}] : 链接无效：[404]${name} : ${url}`)
            }
        }).on('error', (e) => {
            // 错误处理
            res.end(JSON.stringify({
                "code": "500",
                "msg": `主机下线: [500]${name} : ${url}===>>${e.message}`,
                "name": name,
                "url": url
            }))
            console.log(`<链接探测服务> ${new Date()} [${req.socket.remoteAddress}] : 主机下线: [500]${name} : ${url}===>>${e.message}`)
        }).end()
    // HTTPS链接探测
    } else if (url.slice(0, 8) == "https://") {
        https.request({
            host: urls.parse(url, true).host,
            path: urls.parse(url, true).path,
            method: 'HEAD'
        }, (resr) => {
            // 链接状态处理
            if (resr.statusCode >= 200 && resr.statusCode < 400) {
                res.end(JSON.stringify({
                    "code": "200",
                    "msg": `链接正常：[200]${name} : ${url}`,
                    "name": name,
                    "url": url
                }))
                console.log(`<链接探测服务> ${new Date()} [${req.socket.remoteAddress}] : 链接正常：[200]${name} : ${url}`)
            } else {
                // 链接无效处理
                res.end(JSON.stringify({
                    "code": "404",
                    "msg": `链接无效：[404]${name} : ${url}`,
                    "name": name,
                    "url": url
                }))
                console.log(`<链接探测服务> ${new Date()} [${req.socket.remoteAddress}] : 链接无效：[404]${name} : ${url}`)
            }
        }).on('error', (e) => {
            // 错误处理
            res.end(JSON.stringify({
                "code": "500",
                "msg": `主机下线: [500]${name} : ${url}===>>${e.message}`,
                "name": name,
                "url": url
            }))
            console.log(`<链接探测服务> ${new Date()} [${req.socket.remoteAddress}] : 主机下线: [500]${name} : ${url}===>>${e.message}`)
        }).end()
    } else {
        // 协议错误处理
        res.end(JSON.stringify({
            "code": "405",
            "msg": `协议错误：[405]${name} : ${url}`,
            "name": name,
            "url": url
        }))
        console.log(`<链接探测服务> ${new Date()} [${req.socket.remoteAddress}] : 协议错误：[405]${name} : ${url}`)
    }
}).listen(93)